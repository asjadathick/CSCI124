//
//  text2bin.cpp
//  Ass2
//
//  Created by Mohamed Asjad Athick on 5/09/2015.
//  Student 4970512
//  Copyright (c) 2015 Asjad Athick. All rights reserved.
//

#include "text2bin.h"
using namespace std;

int readTxtFile(ifstream &inputFile, Data *&records){
    int recordsLoaded=0;
    //count records in file
    inputFile.open(TEXT_FILE_NAME);
    if (!inputFile.good()) {
        cerr<<"Error opening text file for input"<<endl;
        return 0;
    }
    
    char tempBuffer[TEXT_LENGTH];
    int numberOfRecords=0;
    inputFile.getline(tempBuffer, TEXT_LENGTH,'\n');
    while (strcmp(tempBuffer, "-1")!=0) {
        numberOfRecords++;
        inputFile.getline(tempBuffer, TEXT_LENGTH,'\n');
    }
    numberOfRecords/=2; //2 lines per record
    
    //allocate memory
    records = new Data[numberOfRecords];
    
    //seek back to beg
    inputFile.clear();
    inputFile.seekg(ios::beg);
    
    //assign records
    inputFile.getline(tempBuffer, TEXT_LENGTH, '\n');
    while (strcmp(tempBuffer, "-1")!=0) {
        strcpy(records[recordsLoaded].name,tempBuffer);
        inputFile.getline(tempBuffer, TEXT_LENGTH,' ');
        records[recordsLoaded].age=atoi(tempBuffer);
        inputFile.getline(tempBuffer, TEXT_LENGTH,'\n');
        records[recordsLoaded].balance=atof(tempBuffer);
        //record loaded
        recordsLoaded++;
        //next rec
        inputFile.getline(tempBuffer, TEXT_LENGTH, '\n');
    }
    inputFile.close();
    return recordsLoaded;
}

void writeBinFile(fstream &binaryFile, const Data records[],int size){
    binaryFile.open(BIN_FILE_NAME,ios::out|ios::binary);
    if(!binaryFile.good()){
        cerr<<"Error creating the binary file"<<endl;
        return;
    }
    
    Data temp;
    for (int i=0; i<size; i++) {
        strcpy(temp.name,records[i].name);
        temp.age=records[i].age;
        temp.balance=records[i].balance;
        binaryFile.write(reinterpret_cast<char*>(&temp), sizeof(Data));
    }
    binaryFile.close();
}

int readBinFile(fstream &binaryFile, Data *&records){
    
    binaryFile.open(BIN_FILE_NAME,ios::in);
    if (!binaryFile.good()) {
        cerr<<"Error opening binary file."<<endl;
    }
    
    int numberOfRecords=0;
    
    //figure out num of records
    binaryFile.seekg(ios::end);
    numberOfRecords=(int)binaryFile.tellg()/sizeof(Data);
    
    //seek back
    binaryFile.clear();
    binaryFile.seekg(ios::beg);
    
    //alloc memory
    records=new Data[numberOfRecords];
    
    
    int recordsLoaded=0;
    
    Data temp;
    while (!binaryFile.eof()) {
        binaryFile.read(reinterpret_cast<char*>(&temp), sizeof(Data));
        if (!binaryFile.eof()) {
            records[recordsLoaded]=temp;
            recordsLoaded++;
        }
    }
    return recordsLoaded;
}
