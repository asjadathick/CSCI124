//
//  main.cpp
//  Ass2
//
//  Created by Mohamed Asjad Athick on 5/09/2015.
//  Student 4970512
//  Copyright (c) 2015 Asjad Athick. All rights reserved.
//

#include "text2bin.h"
using namespace std;

//prototypes
void listAllRecords(Data *record, int numOfRecords);

int main(int argc, const char * argv[]) {

    ifstream textfile;
    fstream binaryFile;
    Data *records;
    
    int numRecords=0;
    
    binaryFile.open(BIN_FILE_NAME,ios::in|ios::binary);
    if (!binaryFile.good()) {
        binaryFile.close();
        //does not exist, read from txt and make bin
        numRecords=readTxtFile(textfile, records);
        writeBinFile(binaryFile, records, numRecords);
        listAllRecords(records, numRecords);
    }
    else{
        //read from bin file
        //binaryFile.close();
        //numRecords=readBinFile(binaryFile, records);
        //listAllRecords(records, numRecords);
    }
    
    
    delete [] records;
    /*
    int cmd;
    do {
        cout<<"Select from the following options:"<<endl;
        cout<<"1. Sort by name"<<endl;
        cout<<"2. Sort by age"<<endl;
        cout<<"3. Sort by balance"<<endl;
        cout<<"4. Quit"<<endl;
        cout<<"Select: "<<endl;
        cin>>cmd;
        //handle invalid input?
        switch (cmd) {
            case 1:
                
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
                
            default:
                break;
        }
    }while (cmd!=4);
    */
    return 0;
}

void listAllRecords(Data *record, int numOfRecords){
    for (int i=0; i<numOfRecords; i++) {
        cout<<record[i].name<<'\t'<<record[i].age<<'\t'<<record[i].balance<<'\t'<<endl;
    }
}

